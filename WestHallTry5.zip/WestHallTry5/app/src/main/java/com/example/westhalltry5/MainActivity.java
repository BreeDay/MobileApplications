package com.example.westhalltry5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.button);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Floor 1", "switching to floor 1");
                Intent int1 = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(int1);

            }
        });

        Button btn2 = findViewById(R.id.button2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Floor 2", "switching to floor 2");
                Intent int2 = new Intent(MainActivity.this, floor2.class);
                startActivity(int2);

            }
        });

        Button btn3 = findViewById(R.id.button3);

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Floor 3", "switching to floor 3");
                Intent int3 = new Intent(MainActivity.this, floor3.class);
                startActivity(int3);

            }
        });

        Button btn4 = findViewById(R.id.button4);

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Campus Map", "switching to campus map");
                Intent int4 = new Intent(MainActivity.this, campusmap.class);
                startActivity(int4);

            }
        });

        Button btn5 = findViewById(R.id.button5);

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("About Section", "switching to the about section");
                Intent int5 = new Intent(MainActivity.this, about.class);
                startActivity(int5);

            }
        });
    }


}
